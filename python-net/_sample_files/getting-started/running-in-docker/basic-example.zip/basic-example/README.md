# GroupDocs.Signature for Python via .NET in Docker

Signs `sample.pdf` with a text signature inside a Docker container and writes
`output/signed_sample.pdf` to a folder mounted from the host.

## Build

```bash
docker build -t groupdocs-signature-net:basic-example .
```

## Run

Evaluation mode:

```bash
docker run --rm -v "${PWD}/output:/app/output" groupdocs-signature-net:basic-example
```

With a license. Mount it read-only at run time; never copy it into the image:

```bash
docker run --rm \
    -v "${PWD}/output:/app/output" \
    -v /path/to/license-folder:/license:ro \
    -e GROUPDOCS_LIC_PATH=/license/GroupDocs.Signature.lic \
    groupdocs-signature-net:basic-example
```

On Windows with Git Bash, run `export MSYS_NO_PATHCONV=1` first so that the
container paths are not rewritten.

See https://docs.groupdocs.com/signature/python-net/getting-started/running-in-docker/
for what each system package in the Dockerfile is for.
