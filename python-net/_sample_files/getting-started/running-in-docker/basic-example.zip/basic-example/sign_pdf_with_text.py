import os

from groupdocs.signature import Signature
from groupdocs.signature.options import TextSignOptions


def sign_pdf_with_text():
    # The output folder is mounted from the host, so the signed file outlives the container
    os.makedirs("output", exist_ok=True)
    output_path = os.path.join("output", "signed_sample.pdf")

    with Signature("sample.pdf") as signature:
        options = TextSignOptions("Hello from Docker!")
        options.left = 100
        options.top = 100
        result = signature.sign(output_path, options)

    print(f"Signatures added: {len(result.succeeded)}. File saved at {output_path}")


if __name__ == "__main__":
    sign_pdf_with_text()
