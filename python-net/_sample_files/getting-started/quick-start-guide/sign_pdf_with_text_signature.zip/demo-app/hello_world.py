import groupdocs.signature as gs 
import groupdocs.signature.options as gso 
import sys 
import os

def run():
   
    license = gs.License()
    license.set_license("./GroupDocs.Signature.PythonViaNET.lic")
    
    # The path to the file.
    sample_pdf = "./sample.pdf"

    file_name = os.path.basename("./signed_sample_pdf")

    # The path to the output directory.
    output_directory = "./out"

    if not os.path.exists(output_directory):
        os.makedirs(output_directory)

    output_file_path = os.path.join(output_directory, file_name)

    # Sign document with text signature.
    with gs.Signature(sample_pdf) as signature:
        text_sign_options = gso.TextSignOptions("Hello world!")
        signature.sign(output_file_path, text_sign_options)

    print(f"\nSource document signed successfully.\nFile saved at {output_file_path}")

if __name__ == "__main__":
    run()